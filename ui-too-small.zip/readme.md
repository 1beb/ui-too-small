# UI Too Small 

Simple plugin to increase the size of the text in brackets for those of us using high def on linux.

## News

* 2015-05-19 - updated with lineheight fix courtesy of [Paul Wellner Bou](http://paul.wellnerbou.de/) ([github](https://github.com/paulwellnerbou))
* 2015-05-15 - updated with !importance to fix working files, also added lineheight directive for a bit more space.
